# sooka-free-channels
Live TV Links from sooka (sooka.my), Astro's new streaming service. Playable through OTT Navigator.

# Information
This repository contains free channels only (playable when logged out of the website itself).  
Links could be expired anytime. Download the m3u8 file then change the license server URL.

# Technical Information
Video: Adaptive, Maximum 1280x720 1500Kbps  
Audio: HE-AAC 40Kbps  

# EPG?
Use https://weareblahs.github.io/epg/astro.xml.

# Channel List
 - Astro Arena (Ch 801)
 - Astro Awani (Ch 501)
 - eGG Network (Ch 800)
